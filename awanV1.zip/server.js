require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const flash = require('express-flash');
const { checkAuthStatus, addUnreadNotificationCountToLocals } = require('./middlewares/authMiddleware');
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const apiRoutes = require('./routes/api');
const userRoutes = require('./routes/user');
const geminiApiRoutes = require('./geminiApi');
const app = express();
const PORT = process.env.PORT || 3000;
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.error('MongoDB Connection Error:', err));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use(session({
    secret: process.env.SESSION_SECRET || 'your_very_secret_session_key_here',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 60000 * 60 }
}));
app.use(flash());
app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    next();
});


app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(checkAuthStatus);
app.use(addUnreadNotificationCountToLocals);


app.get('/', (req, res) => {
  res.render('index', { title: 'Home' });
});
app.get('/premium', (req, res) => {
    res.render('premium', { title: 'Premium Features'});
});

app.use('/', authRoutes);
app.use('/admin', adminRoutes);
app.use('/api', apiRoutes);
app.use('/user', userRoutes);
geminiApiRoutes(app);

app.use((req, res, next) => {
    const error = new Error('Not Found');
    error.status = 404;
    next(error);
});

app.use((error, req, res, next) => {
    res.status(error.status || 500);
    if (req.originalUrl.startsWith('/api/')) {
        return res.json({
            error: { message: error.message }
        });
    }
    console.error("Global Error Handler:", error);
    res.render('error', {
        title: 'Error',
        message: error.message,
        status: error.status || 500,
    });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});