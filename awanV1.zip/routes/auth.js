const express = require('express');
const router = express.Router();
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const { protect } = require('../middlewares/authMiddleware');
router.get('/register', (req, res) => {
    console.log('GET /register - Rendering registration page');
    res.render('register', { title: 'Register' });
});

router.post('/register', async (req, res) => {
  console.log('POST /register - Attempting registration for:', req.body.email);
  const { username, email, password } = req.body;
  try {
    if (!username || !email || !password) {
        console.log('Registration failed: Missing fields');
        return res.status(400).render('register', { title: 'Register', error: 'All fields are required', formData: req.body });
    }
    const userExists = await User.findOne({ $or: [{ email: email.toLowerCase() }, { username }] });
    if (userExists) {
      console.log('Registration failed: User exists -', email);
      return res.status(400).render('register', { title: 'Register', error: 'User with that email or username already exists', formData: req.body });
    }
    const user = await User.create({ username, email, password });
    console.log('Registration successful for:', user.email, '- Redirecting to /login');
    res.redirect('/login');
  } catch (error) {
    console.error('ERROR DURING REGISTRATION:', error);
    res.status(500).render('register', { title: 'Register', error: 'Server error during registration. Please try again.', formData: req.body });
  }
});

router.get('/login', (req, res) => {
    console.log('GET /login - Rendering login page');
    res.render('login', { title: 'Login' });
});

router.post('/login', async (req, res) => {
  console.log('POST /login - Attempting login for:', req.body.email);
  const { email, password } = req.body;
  try {
    if (!email || !password) {
        console.log('Login failed: Missing fields');
        return res.status(400).render('login', { title: 'Login', error: 'Email and password are required', email });
    }
    const user = await User.findOne({ email: email.toLowerCase() });
    if (user && (await user.matchPassword(password))) {
      const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1d' });
      res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 24 * 60 * 60 * 1000 });
      console.log('Login successful for:', user.email, '- Redirecting...');
      res.redirect(user.role === 'admin' ? '/admin/dashboard' : '/');
    } else {
      console.log('Login failed: Invalid credentials for -', email);
      res.status(401).render('login', { title: 'Login', error: 'Invalid email or password', email });
    }
  } catch (error) {
    console.error('ERROR DURING LOGIN:', error);
    res.status(500).render('login', { title: 'Login', error: 'Server error during login. Please try again.', email });
  }
});

router.get('/logout', (req, res) => {
  console.log('GET /logout - Logging out user');
  res.clearCookie('token');
  res.redirect('/login');
});

router.get('/profile', protect, (req, res) => {
    console.log('GET /profile - Rendering profile page for user:', req.user.email);
    res.render('profile', { title: 'My Profile', user: req.user });
});

module.exports = router;