const express = require('express');
const router = express.Router();
const Promo = require('../models/promo');
router.get('/promos', async (req, res) => {
  try {
    const promos = await Promo.find({ isActive: true, endDate: { $gte: new Date() } })
                              .sort({ createdAt: -1 })
                              .select('title description code discountPercentage endDate');
    res.render('promos', { title: 'Available Promos', promos }); 
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { title: 'Error', message: 'Could not load promos.', status: 500});
  }
});


module.exports = router;