const axios = require("axios");
const apiKeyAuth = require('./middlewares/apiKeyAuth'); 
module.exports = (app) => {
  async function gemini(prompt) {
    const apiUrl = `https://gemini-api-5k0h.onrender.com/gemini/chat`;
    const params = {
      q: prompt
    };
    try {
        const response = await axios.get(apiUrl, { params });
        return response.data?.content || 'Failed Response Ai';
    } catch (error) {
        console.error("Error calling Gemini API:", error.message);
        if (error.response) {
            console.error("Gemini API Response Data:", error.response.data);
            console.error("Gemini API Response Status:", error.response.status);
        }
        return 'Failed to get response from AI due to an error.';
    }
  }

  app.get("/api/ai/gemini", apiKeyAuth, async (req, res) => {
    try {
      const { prompt } = req.query;

      if (!prompt) {
        return res.status(400).json({
          status: false, error: "prompt required"
        });
      }

      const result = await gemini(prompt);
      res.status(200).json({
        status: true,
        result: result.replaceAll("**", "*"), 
      });
    } catch (error) {
      res.status(500).json({
        status: false, error: error.message
      });
    }
  });
};