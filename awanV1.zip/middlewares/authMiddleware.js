const jwt = require('jsonwebtoken');
const User = require('../models/user');
const Notification = require('../models/notification');
const protect = async (req, res, next) => {
  let token;
  if (req.cookies.token) {
    try {
      token = req.cookies.token;
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        res.clearCookie('token');
        if (req.flash) req.flash('error_msg', 'Sesi tidak valid, silakan login kembali.');
        return res.status(401).redirect('/login');
      }
      next();
    } catch (error) {
      console.error(error);
      res.clearCookie('token');
      if (req.flash) req.flash('error_msg', 'Sesi berakhir atau tidak valid, silakan login kembali.');
      return res.status(401).redirect('/login');
    }
  } else {
    if (req.flash) req.flash('error_msg', 'Anda harus login untuk mengakses halaman ini.');
    res.status(401).redirect('/login');
  }
};

const isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    if(req.flash) req.flash('error_msg', 'Akses ditolak: Anda bukan admin.');
    res.status(403).redirect('/');
  }
};

const checkAuthStatus = async (req, res, next) => {
  let token;
  res.locals.user = null;
  if (req.cookies.token) {
    try {
      token = req.cookies.token;
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id).select('-password');
      if (user) {
        res.locals.user = user;
      }
    } catch (error) {
      res.clearCookie('token');
    }
  }
  next();
};
const addUnreadNotificationCountToLocals = async (req, res, next) => {
    if (res.locals.user) { 
        try {
            const count = await Notification.countDocuments({ userId: res.locals.user._id, isRead: false });
            res.locals.unreadNotificationsCount = count;
        } catch (error) {
            console.error("Error fetching unread notification count:", error);
            res.locals.unreadNotificationsCount = 0;
        }
    } else {
        res.locals.unreadNotificationsCount = 0;
    }
    next();
};


module.exports = { protect, isAdmin, checkAuthStatus, addUnreadNotificationCountToLocals };